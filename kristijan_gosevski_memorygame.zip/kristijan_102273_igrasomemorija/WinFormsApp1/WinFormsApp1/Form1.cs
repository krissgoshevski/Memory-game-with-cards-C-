﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        int time = 200;
        Timer timer = new Timer { Interval = 1000 };

        Random rnd = new Random();

        List<string> lista = new List<string>()
        {

            "Z", "V", "G", "O", "E","T", "P", "W", "L",

            "A","S", "R", "X", "Y", "O", "Q", "W", "N",

            "Z", "V", "G", "O", "E","T", "P", "W", "L",

            "A","S", "R", "X", "Y", "O", "Q", "W", "N",
        };

        Button prvoklikanje, vtoroklikanje;

        public Form1()
        {
            InitializeComponent();
            prvametoda();
        
        }

        private void startuvanje()
        {
            timer.Start();
            timer.Tick += delegate
            {
                time--;

                if (time == 0)
                {
                    timer.Stop();
                    rezultat.Text = "Повеќе среќа следниот пат ! ";
                 
                   
                }
                var ssTime = TimeSpan.FromSeconds(time);
                vreme.Text = "Преостанато време" + Environment.NewLine + "00:" + time.ToString();
            };

        }

        private void prvametoda()
        {
            Button button;
         
            int slucaenBroj;

            for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                if (tableLayoutPanel1.Controls[i] is Button)
                {
                    button = (Button)tableLayoutPanel1.Controls[i];
                }
                else
                    continue;

                slucaenBroj = rnd.Next(0, lista.Count);
                button.Text = lista[slucaenBroj];

                lista.RemoveAt(slucaenBroj);

            }
        }

        private void button_click(object sender, EventArgs e)
        {
            if (prvoklikanje != null && vtoroklikanje != null)
                 return;
          
            Button clickedButton = sender as Button;

            if (clickedButton == null)
                  return;

            if (clickedButton.ForeColor == Color.Black)
                  return;

            if (prvoklikanje == null)
            {
                prvoklikanje = clickedButton;
                prvoklikanje.ForeColor = Color.Black;
                  return;
            }

            vtorametoda();
            vtoroklikanje = clickedButton;
            vtoroklikanje.ForeColor = Color.Black;


            if (prvoklikanje.Text == vtoroklikanje.Text)
            {
               prvoklikanje.BackColor = Color.Green;
               vtoroklikanje.BackColor = Color.Green;
                prvoklikanje = null;
                vtoroklikanje = null;
                vtorametoda();

            }
              else
                timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();

            prvoklikanje.ForeColor = prvoklikanje.BackColor;
            vtoroklikanje.ForeColor = vtoroklikanje.BackColor;

            prvoklikanje = null;
            vtoroklikanje = null;
        }

        private void vtorametoda()
        {
            Button button;
            for (int i = 0; i < tableLayoutPanel1.Controls.Count; i++)
            {
                button = tableLayoutPanel1.Controls[i] as Button;
            
                if (button != null && (button.BackColor != Color.Green || button.ForeColor != Color.Black))
                {
                    return;
                }
                rezultat.Text = "ЧЕСТИТКИ, УСПЕШНО ЗАВРШЕНА ИГРА !";
                timer.Stop();


                if (button != null && button.ForeColor == button.BackColor)
                {
                    return;

                }

            }
        }

        private void start_click_Click(object sender, EventArgs e)
        {
            startuvanje();
            
            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            button4.Visible = true;
            button5.Visible = true;
            button6.Visible = true;
            button7.Visible = true;
            button8.Visible = true;
            button9.Visible = true;
            button10.Visible = true;
            button11.Visible = true;
            button12.Visible = true;
            button13.Visible = true;
            button14.Visible = true;
            button15.Visible = true;
            button16.Visible = true;
            button17.Visible = true;
            button18.Visible = true;
            button19.Visible = true;
            button20.Visible = true;
            button21.Visible = true;
            button22.Visible = true;
            button23.Visible = true;
            button24.Visible = true;
            button25.Visible = true;
            button26.Visible = true;
            button27.Visible = true;
            button28.Visible = true;
            button29.Visible = true;
            button30.Visible = true;
            button31.Visible = true;
            button32.Visible = true;
            button33.Visible = true;
            button34.Visible = true;
            button35.Visible = true;
            button36.Visible = true;


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
